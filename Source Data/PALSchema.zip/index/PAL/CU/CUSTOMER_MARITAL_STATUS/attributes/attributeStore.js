{
  "5": {
    "type": 73,
    "flags": 16385,
    "realName": "$trex_udiv$"},
  "7": {
    "type": 66,
    "flags": 134217729,
    "realName": "$rowid$",
    "intDigits": 18},
  "201": {
    "type": 73,
    "flags": 17,
    "realName": "CUSTOMER_MARITAL_STATUS_ID"},
  "202": {
    "type": 83,
    "flags": 1,
    "realName": "CUSTOMER_MARITAL_STATUS_NAME"}}
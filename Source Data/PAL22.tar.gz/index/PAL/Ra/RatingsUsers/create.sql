CREATE COLUMN TABLE "PAL"."RatingsUsers" ("user" NVARCHAR(255) NOT NULL , "gender" NVARCHAR(255), "country" NVARCHAR(255), "generation" NVARCHAR(255), PRIMARY KEY ("user")) UNLOAD PRIORITY 5  AUTO MERGE ;
COMMENT ON COLUMN "PAL"."RatingsUsers"."user" is ' ';
COMMENT ON COLUMN "PAL"."RatingsUsers"."gender" is ' ';
COMMENT ON COLUMN "PAL"."RatingsUsers"."country" is ' ';
COMMENT ON COLUMN "PAL"."RatingsUsers"."generation" is ' '
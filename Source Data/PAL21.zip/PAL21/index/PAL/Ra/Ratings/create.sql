CREATE COLUMN TABLE "PAL"."Ratings" ("user" NVARCHAR(255) NOT NULL , "album" NVARCHAR(255) NOT NULL , "rating" INTEGER CS_INT, PRIMARY KEY INVERTED VALUE ("user", "album")) UNLOAD PRIORITY 5  AUTO MERGE ;
COMMENT ON COLUMN "PAL"."Ratings"."user" is ' ';
COMMENT ON COLUMN "PAL"."Ratings"."album" is ' ';
COMMENT ON COLUMN "PAL"."Ratings"."rating" is ' '
CREATE COLUMN TABLE "PAL"."RatingsAlbums" ("album" NVARCHAR(255) NOT NULL , "artist" NVARCHAR(255), "released" INTEGER CS_INT, "genre" NVARCHAR(255), "totalCertifiedCopies" DOUBLE CS_DOUBLE, "claimedSales" INTEGER CS_INT, PRIMARY KEY ("album")) UNLOAD PRIORITY 5  AUTO MERGE ;
COMMENT ON COLUMN "PAL"."RatingsAlbums"."album" is ' ';
COMMENT ON COLUMN "PAL"."RatingsAlbums"."artist" is ' ';
COMMENT ON COLUMN "PAL"."RatingsAlbums"."released" is ' ';
COMMENT ON COLUMN "PAL"."RatingsAlbums"."genre" is ' ';
COMMENT ON COLUMN "PAL"."RatingsAlbums"."totalCertifiedCopies" is ' ';
COMMENT ON COLUMN "PAL"."RatingsAlbums"."claimedSales" is ' '